"""medusa.__init__
"""

# created 2002/03/19, AMK

__revision__ = "$Id: __init__.py 1592 2009-07-30 14:55:41Z iko $"
